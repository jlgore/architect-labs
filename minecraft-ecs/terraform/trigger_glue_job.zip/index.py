import boto3
import os
import json

def handler(event, context):
    glue_client = boto3.client('glue')
    job_name = os.environ['GLUE_JOB_NAME']
    
    try:
        response = glue_client.start_job_run(JobName=job_name)
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f'Successfully started Glue job: {job_name}',
                'jobRunId': response['JobRunId']
            })
        }
    except Exception as e:
        print(f'Error starting Glue job {job_name}: {str(e)}')
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': f'Error starting Glue job: {str(e)}'
            })
        }
